setwd("~/Library/Mobile Documents/com~apple~CloudDocs/University/UNIL/projects/Reconciling-Scarr-Rowe-and-Compensatory-Advantage-Hypotheses")


source("code/funs.R")


# BOOTSTRAPPING ######################################################
set.seed(123)
outcome   <- "college"
predictor <- "pgi_education"
fun_out   <- "median"
fun_pred  <- "median"
n_boot    <- 10000


mclapply(c("WLS","ELSA"), function(ds) {
  
  # Get data
  data <- get_data(ds)
  
  # Split by gender
  mclapply(c("female","male"), function(which_sex) {
    
    data <- filter(data, sex == which_sex)
    
    # Set metrics and compute them
    metrics <- c("TPR","TNR","FPR","FNR")
    results <- compute_group_metrics_boot(data, metrics, outcome, predictor, fun_out, fun_pred, n_boot)
    
    # Write
    saveRDS(results, paste0("results/gender/",ds,"_",outcome,"_",fun_pred,"_",n_boot,"_",which_sex,".rsd"))
    
  }, mc.cores=2)
  

}, mc.cores=2)



# RESULTS TABLE ######################################################
source("code/funs.R")


outcome   <- "college"
predictor <- "pgi_education"
fun_out   <- "median"
fun_pred  <- "median"
n_boot    <- 10000

# Read results
results <- lapply(c("WLS","ELSA"), function(ds) {
  
  # By gender
  lapply(c("female","male"), function(which_sex) {
    
    # Read
    results <- readRDS(paste0("results/gender/",ds,"_",outcome,"_",fun_pred,"_",n_boot,"_",which_sex,".rsd"))
    results %>% mutate(dataset = ds, sex = which_sex) %>% 
      filter(metric %in% c("TPR", "TNR"))
  
  })
})

results <- bind_rows(results)

# Set labels
results <- results %>% 
  mutate(status  = ifelse(metric=="TPR", "College", "No College"),
         group   = factor(group, levels=c("Low SES", "High SES")),
         dataset = factor(dataset, levels=c("WLS", "ELSA")),
         sex     = factor(sex, levels = c("female","male"))
  )

# Keep pvalues and adjust
pvalues <- results %>% 
  filter(group=="High SES") %>%
  select(dataset, outcome, sex, status, metric, p_value, stars) %>% 
  mutate(p_value.adj = p.adjust(p_value, method = "holm"),
         stars.adj   = add_stars(p_value.adj))
pvalues




# MAIN PLOT ######################################################

ds <- "ELSA"

# - Perc plot

# By gender
results <- lapply(c("female","male"), function(which_sex) {
  readRDS(paste0("results/gender/",ds,"_",outcome,"_",fun_pred,"_",n_boot,"_",which_sex,".rsd")) %>%
    mutate(dataset=ds, 
           status=ifelse(high_OUT==1,"College","No College"),
           sex = which_sex)

})

results <- bind_rows(results)

# Correct stars
pvalues_ds <- filter(pvalues, dataset == ds) %>% select(dataset, status, sex, stars.adj)
results    <- merge(results, pvalues_ds, by=c("dataset","status","sex"))
adjust_pvalues <- ifelse("stars.adj" %in% colnames(results),T,F)

# Plot
plot_perc(results, c("FNR", "FPR"), adjust_pvalues) + facet_grid(sex~real, scales="free_x")

# Save
ggsave(paste0("plots/",ds,"_",outcome,"_gender.png"), width = 9, height =9)





