setwd("~/Library/Mobile Documents/com~apple~CloudDocs/University/UNIL/projects/Reconciling-Scarr-Rowe-and-Compensatory-Advantage-Hypotheses")


# =========================================================
#                  ✨ REGRESSION ANALYSIS ✨
# =========================================================

source("code/funs.R")



# Settings
predictor <- "pgi_education"
outcomes  <- c("high_school","college")
datasets  <- c("WLS","ELSA")


RunRegression <- function(ds, which_model, outcome, predictor, keller) {
  
  # - 1 - Prepare
  data = get_data(ds)
  data[predictor] = as.vector(scale(data[predictor]))
  data$SES = factor(data$SES, levels = c("Low SES", "High SES"))
  
  
  # ---  Create all interactions
  controls          <- c(DEMO, PC_vars)
  pred_interactions <- paste0(predictor, "*", controls)
  ses_interactions  <- paste0("SES*", controls)
  
  # Combine in formula
  formula <- paste0(outcome, " ~ ", predictor, "*SES + ",
                    paste(controls, collapse = " + "))
  if (keller) formula <- paste0(formula, " + ",
                                paste(pred_interactions, collapse = " + "), " + ",
                                paste(ses_interactions, collapse = " + "))
  formula = as.formula(formula)
  
  
  # - 2 - Run models
  
  if (which_model=="LPM") {
    # LPM
    model <- lm(formula, data = data)
  } else if (which_model=="Logistic") {
    # LOGIT
    model <- glm(formula, data = data, family = binomial(link = "logit"))
  } else {
    cat(which_model, "is not an available option, try: 'LPM' or 'Logistic' ")
    stop()
  }
  
  # Return model
  return(model)
}




PlotRegression <- function(model_name) {
  
  # Get model
  model <- models[grepl(model_name, names(models))][[1]]
  
  # Coefficient of interaction
  coefs <- coef(summary(model))[paste0(predictor,":SESHigh SES"), ]
  
  if(model_name=="Logistic") {
    coef       <- exp(coefs["Estimate"]) %>% round(2)
    coef_label <- "OR:"
    pvalue     <- coefs["Pr(>|z|)"]
  } else {
    coef       <- coefs["Estimate"] %>% round(2)
    coef_label <- "beta:"
    pvalue     <- coefs["Pr(>|t|)"]
  }
  
  # Label
  label = paste(coef_label, coef, add_stars(pvalue))
  
  # Get predictions
  preds <- ggpredict(model, terms = c(paste(predictor,"[all]"), "SES"))
  
  # Plot
  plot(preds) +
    annotate("label",
             label=label, 
             label.size = 0,
             x = -1.5, y = 0.85,
             hjust = 0, size=7) +
    labs(title="", x = "PGI", y = "Predicted probability\n") +
    theme_minimal() +
    theme(text         = element_text(size=24),
          title        = element_text(size=18),
          axis.title.y = element_text(size=22),
          panel.grid.minor = element_blank()) +
    scale_fill_manual(values=SES.colors, name="") +
    scale_color_manual(values=SES.colors, name="") +
    xlim(c(-2,2)) +
    ylim(c(0,1))
  
}



# For each outcome
for (outcome in outcomes)  {

  #################  RUN REGRESSIONS  ################# 
  
  # === Datasets
  models_all <- lapply(datasets, function(ds) {
    
    # === Model specification
    models_type <- lapply(c("LPM","Logistic"), function(which_model) {
      
      # === Keller adjustment
      models_keller <- lapply(c(F,T), function(keller) {
      
        # === Run regression
        RunRegression(ds, which_model, outcome, predictor, keller)
    
      })
      c("NoKeller"=models_keller[1], "Keller"=models_keller[2])
      
    })
    c("LPM" = models_type[[1]], "Logistic" = models_type[[2]])
  
  })
  
  
  # Combine all models for an outcome
  models <- c("WLS"= models_all[[1]], "ELSA" = models_all[[2]])
  
  
  # Select only variables of interest
  coef_map <- c("pgi_education" = "PGI", "SESHigh SES" = "SES",
                "pgi_education:SESHigh SES" = "PGI×SES")
  
  
  # Export to LaTeX table
  modelsummary(
    models,
    stars = TRUE,
    coef_map = coef_map,
    exponentiate = c(F,F,T,T,F,F,T,T),
    #output = paste0("tables/regressions_",outcome,".txt"),
    output="latex",
    fmt = 2,
    gof_omit = ".*"
  ) %>% print()
  
  
  
  ############ PLOTS ############ 
  
  p <- lapply(datasets, function(ds) {
    
    # Select dataset
    models <- models[grepl(ds, names(models))]
    
    # Keep NoKeller
    models <- models[grepl("NoKeller", names(models))]
    
    
    # Plot and combine
    plot <- ggarrange(PlotRegression("LPM"), 
                      PlotRegression("Logistic"), 
                      ncol=1, common.legend = T, 
                      legend = "bottom")
    
    # Show
    plot
    
    # Save
    ggsave(paste0("plots/",ds,"_regs_",outcome,".pdf"), width = 5, height = 10)
    
  })

  
  
}








